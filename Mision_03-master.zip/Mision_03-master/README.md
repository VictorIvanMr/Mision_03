# Mision_03

## Funciones

Consulta el documento anexo **Mision_03.pdf** para ver los detalles.


1. Clona el proyecto desde Github.
2. Crea un proyecto especial en Pycharm.
3. Agrega a tu proyecto cada uno de los programas solicitados. **NOMBRA TUS PROGRAMAS COMO LO INDICA EL DOCUMENTO.**
4. Sube a Github cada programa terminado.
5. Desde la página de Github, abre un Pull Request para que te califique. (Escribe tus datos completos en el Pull request para tener derecho a ganar XP o monedas)

Si cumples esta misión, podrás conservar hasta 1250 puntos de HP.

Si eres uno de los **primeros 5 alumnos** que completen esta misión, obtendrás **100 XP**.

Si cumples de manera **IMPECABLE** con esta misión, ganarás UNA MONEDA. Esta moneda te dará el poder para **recuperar HP** que hayas perdido en misiones anteriores.

***

### ¿Y para qué sirven los XP que estoy ganando?

Entre otras cosas:

- Por 200 XP podrás preguntar al profesor si tu respuesta a una pregunta del examen teórico es correcta.

- Por 300 XP podrás preguntar al profesor la respuesta correcta de una pregunta del examen teórico.

- Por 100 XP podrás pedir al profesor que descarte la mitad de las opciones en una pregunta del examen teórico.
